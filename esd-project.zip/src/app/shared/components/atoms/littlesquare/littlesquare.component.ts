import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-littlesquare',
  templateUrl: './littlesquare.component.html',
  styleUrls: ['./littlesquare.component.css']
})
export class LittlesquareComponent implements OnInit {

  constructor() { }

  @Input() public is: string;
  @Input() public num: string;

  ngOnInit(): void {
  }

}
