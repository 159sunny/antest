import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LittlesquareComponent } from './littlesquare.component';

describe('LittlesquareComponent', () => {
  let component: LittlesquareComponent;
  let fixture: ComponentFixture<LittlesquareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LittlesquareComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LittlesquareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
