import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PeopletotalComponent } from './peopletotal.component';

describe('PeopletotalComponent', () => {
  let component: PeopletotalComponent;
  let fixture: ComponentFixture<PeopletotalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PeopletotalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PeopletotalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
