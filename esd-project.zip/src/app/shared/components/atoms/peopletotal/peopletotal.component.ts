import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-peopletotal',
  templateUrl: './peopletotal.component.html',
  styleUrls: ['./peopletotal.component.css']
})
export class PeopletotalComponent implements OnInit {

  @Input() public totalnum: string;

  constructor() { }

  ngOnInit(): void {
  }

}
