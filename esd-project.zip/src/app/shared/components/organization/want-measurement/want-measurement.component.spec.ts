import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WantMeasurementComponent } from './want-measurement.component';

describe('WantMeasurementComponent', () => {
  let component: WantMeasurementComponent;
  let fixture: ComponentFixture<WantMeasurementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WantMeasurementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WantMeasurementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
