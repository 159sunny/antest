import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-want-measurement',
  templateUrl: './want-measurement.component.html',
  styleUrls: ['./want-measurement.component.css']
})
export class WantMeasurementComponent implements OnInit {

  constructor() { }

  title='待測量的設備'

  ngOnInit(): void {
  }

}
