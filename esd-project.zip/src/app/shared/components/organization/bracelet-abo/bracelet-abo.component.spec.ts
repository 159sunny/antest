import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BraceletAboComponent } from './bracelet-abo.component';

describe('BraceletAboComponent', () => {
  let component: BraceletAboComponent;
  let fixture: ComponentFixture<BraceletAboComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BraceletAboComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BraceletAboComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
