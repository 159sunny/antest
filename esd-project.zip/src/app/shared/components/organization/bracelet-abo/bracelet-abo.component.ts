import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bracelet-abo',
  templateUrl: './bracelet-abo.component.html',
  styleUrls: ['./bracelet-abo.component.css']
})
export class BraceletAboComponent implements OnInit {

  title = '静电手环异常人数及分数';
  items = [{ is: 'IS1', num: 2 }, { is: 'IS2', num: 2 }, { is: 'IS3', num: 1 }];
  total = '5';
  constructor() { }

  ngOnInit(): void {
  }

}
