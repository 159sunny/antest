import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EsdMonscComponent } from './esd-monsc.component';

describe('EsdMonscComponent', () => {
  let component: EsdMonscComponent;
  let fixture: ComponentFixture<EsdMonscComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EsdMonscComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EsdMonscComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
