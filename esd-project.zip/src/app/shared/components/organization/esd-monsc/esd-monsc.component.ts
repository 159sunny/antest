import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esd-monsc',
  templateUrl: './esd-monsc.component.html',
  styleUrls: ['./esd-monsc.component.css']
})
export class EsdMonscComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
