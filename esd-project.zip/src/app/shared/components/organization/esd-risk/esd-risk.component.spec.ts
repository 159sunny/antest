import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EsdRiskComponent } from './esd-risk.component';

describe('EsdRiskComponent', () => {
  let component: EsdRiskComponent;
  let fixture: ComponentFixture<EsdRiskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EsdRiskComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EsdRiskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
