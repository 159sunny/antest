import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esd-risk',
  templateUrl: './esd-risk.component.html',
  styleUrls: ['./esd-risk.component.css']
})
export class EsdRiskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
