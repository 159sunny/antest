import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esd-abo',
  templateUrl: './esd-abo.component.html',
  styleUrls: ['./esd-abo.component.css']
})
export class EsdAboComponent implements OnInit {

  title = '设备异常异常及分布';
  items = [{ is: 'MLB-ISA-2', num: 1 }, { is: 'MLB-ISA-3', num: 1 }, { is: 'SMT-IS6-3', num: 1 }];
  total = '3';

  constructor() { }

  ngOnInit(): void {
  }

}
