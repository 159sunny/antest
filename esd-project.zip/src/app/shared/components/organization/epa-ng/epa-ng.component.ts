import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-epa-ng',
  templateUrl: './epa-ng.component.html',
  styleUrls: ['./epa-ng.component.css']
})
export class EpaNgComponent implements OnInit {


  constructor() { }

  title = 'EPA设备闸机测试NG人数及分布';
  items = [{ is: 'MEZ100', num: 14 }, { is: 'MEZ200', num: 5 }, { is: 'MEU500S', num: 4 }];
  total = '23';

  ngOnInit(): void {
  }

}
