import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EpaNgComponent } from './epa-ng.component';

describe('EpaNgComponent', () => {
  let component: EpaNgComponent;
  let fixture: ComponentFixture<EpaNgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EpaNgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EpaNgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
