import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-th-aboinfo',
  templateUrl: './th-aboinfo.component.html',
  styleUrls: ['./th-aboinfo.component.css']
})
export class ThAboinfoComponent implements OnInit {

  constructor() { }
  title='溫濕度異常信息'
  ngOnInit(): void {
  }

}
