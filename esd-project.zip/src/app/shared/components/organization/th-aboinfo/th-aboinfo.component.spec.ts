import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThAboinfoComponent } from './th-aboinfo.component';

describe('ThAboinfoComponent', () => {
  let component: ThAboinfoComponent;
  let fixture: ComponentFixture<ThAboinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThAboinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThAboinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
