import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EpaEchartsComponent } from './epa-echarts.component';

describe('EpaEchartsComponent', () => {
  let component: EpaEchartsComponent;
  let fixture: ComponentFixture<EpaEchartsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EpaEchartsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EpaEchartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
