import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-peoplecounting',
  templateUrl: './peoplecounting.component.html',
  styleUrls: ['./peoplecounting.component.css']
})
export class PeoplecountingComponent implements OnInit {

  @Input() public title: string;
  @Input() public items: any[];
  @Input() totalnum;

  constructor() { }

  ngOnInit(): void {
    if (this.items) {
      this.items.forEach(element => {
        console.log(element.is);
      });
    }

  }


}
