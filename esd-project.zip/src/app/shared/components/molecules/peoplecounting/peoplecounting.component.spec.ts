import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PeoplecountingComponent } from './peoplecounting.component';

describe('PeoplecountingComponent', () => {
  let component: PeoplecountingComponent;
  let fixture: ComponentFixture<PeoplecountingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PeoplecountingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PeoplecountingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
