import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentinfoComponent } from './equipmentinfo.component';

describe('EquipmentinfoComponent', () => {
  let component: EquipmentinfoComponent;
  let fixture: ComponentFixture<EquipmentinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
