import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipmentinfo',
  templateUrl: './equipmentinfo.component.html',
  styleUrls: ['./equipmentinfo.component.css']
})
export class EquipmentinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
