import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { IndexcomponentComponent } from './pages/indexcomponent/indexcomponent.component';
import { HeaderComponent } from './shared/components/organization/header/header.component';
import { LittlesquareComponent } from './shared/components/atoms/littlesquare/littlesquare.component';
import { PeoplecountingComponent } from './shared/components/molecules/peoplecounting/peoplecounting.component';
import { PeopletotalComponent } from './shared/components/atoms/peopletotal/peopletotal.component';
import { BraceletAboComponent } from './shared/components/organization/bracelet-abo/bracelet-abo.component';
import { EsdAboComponent } from './shared/components/organization/esd-abo/esd-abo.component';
import { EpaNgComponent } from './shared/components/organization/epa-ng/epa-ng.component';
import { ThAboinfoComponent } from './shared/components/organization/th-aboinfo/th-aboinfo.component';
import { WantMeasurementComponent } from './shared/components/organization/want-measurement/want-measurement.component';
import { EsdMonscComponent } from './shared/components/organization/esd-monsc/esd-monsc.component';
import { EsdRiskComponent } from './shared/components/organization/esd-risk/esd-risk.component';
import { EpaEchartsComponent } from './shared/components/molecules/epa-echarts/epa-echarts.component';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';
import { EquipmentinfoComponent } from './shared/components/molecules/equipmentinfo/equipmentinfo.component';



@NgModule({
  declarations: [
    AppComponent,
    IndexcomponentComponent,
    HeaderComponent,
    LittlesquareComponent,
    PeoplecountingComponent,
    PeopletotalComponent,
    BraceletAboComponent,
    EsdAboComponent,
    EpaNgComponent,
    ThAboinfoComponent,
    WantMeasurementComponent,
    EsdMonscComponent,
    EsdRiskComponent,
    EpaEchartsComponent,
    EquipmentinfoComponent,],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxEchartsModule.forRoot({
      echarts,
    }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
