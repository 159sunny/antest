import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indexcomponent',
  templateUrl: './indexcomponent.component.html',
  styleUrls: ['./indexcomponent.component.css']
})
export class IndexcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
